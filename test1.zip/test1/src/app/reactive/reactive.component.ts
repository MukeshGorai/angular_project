import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,FormBuilder, Validator, Validators} from '@angular/forms';


@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.css']
})
export class ReactiveComponent implements OnInit {

 

  ngOnInit() {
  }
  onSubmit(){
    console.warn(this.customreForm.value);
  }
  // customerForm=this.fb.group({
  //   fname:['', Validators.required],
  //   lname:['',Validators.required],
  //   address: this.fb.group({
  //     street:['',Validators.required],
  //     state:['',Validators.required],
  //     zipcode:['', Validators.maxLength(6)],
  //     city:['',Validators.required],
  //   })
  // })

  customreForm=new FormGroup({
    fname:new FormControl('', Validators.required),
    lname:new FormControl('', Validators.required),
    password:new FormControl('', Validators.required),
  })
  constructor(private fb: FormBuilder){}
}

