import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  //name=new FormControl('');
  // customerForm=new FormGroup({
  //   fname: new FormControl(''),
  //   lname: new FormControl(''),
  //   address: new FormGroup({
  //     street: new FormControl(''),
  //     city: new FormControl(''),
  //     state: new FormControl(''),
  //     zipcode: new FormControl('')
  //   }),
  // });
}
