import { Subject } from 'rxjs';

export class UserService{
    userActived=new Subject();
}